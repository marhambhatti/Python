import json as js

books = []
students = []
issued_Books = []


# ----------------- ID GENERATORS -----------------

def generate_Student_id():
    return len(students) + 1


def generate_Books_ID():
    return len(books) + 1


# ----------------- LOAD DATA -----------------

def load_data():
    global books, students, issued_Books

    try:
        with open("book.txt", "r") as f:
            books = js.load(f)
    except:
        books = []

    try:
        with open("student.txt", "r") as f:
            students = js.load(f)
    except:
        students = []

    try:
        with open("issued.txt", "r") as f:
            issued_Books = js.load(f)
    except:
        issued_Books = []


# ----------------- SAVE DATA -----------------

def save_books():
    with open("book.txt", "w") as f:
        js.dump(books, f, indent=4)


def save_students():
    with open("student.txt", "w") as f:
        js.dump(students, f, indent=4)


def save_issued():
    with open("issued.txt", "w") as f:
        js.dump(issued_Books, f, indent=4)


# ----------------- FIND FUNCTIONS -----------------

def findBook(book_id):
    for book in books:
        if book["bookId"] == book_id:
            return book
    return None


def findStudent(student_id):
    for student in students:
        if student["Student_Id"] == student_id:
            return student
    return None


# ----------------- ADD BOOK -----------------

def addBook():
    title = input("Enter The Book Title: ")
    author = input("Enter The Name Of Author: ")

    book = {
        "bookId": generate_Books_ID(),
        "title": title,
        "author": author,
        "available": True
    }

    books.append(book)
    save_books()

    print(f"Book added successfully! ID = {book['bookId']}")


# ----------------- VIEW BOOKS -----------------

def viewBooks():
    print("\nAll Books")

    if not books:
        print("No Books Added Yet")
        return

    for book in books:
        print(
            f"ID: {book['bookId']} | "
            f"Title: {book['title']} | "
            f"Author: {book['author']} | "
            f"Available: {book['available']}"
        )


# ----------------- ADD STUDENT -----------------

def addStudents():
    name = input("Enter Student Name: ")
    age = input("Enter Age: ")
    if not name and age:
        print("Please Enter name and age ")
        return
    student = {
        "Student_Id": generate_Student_id(),
        "name": name,
        "age": age
    }

    students.append(student)
    save_students()

    print(f"Student added successfully! ID = {student['Student_Id']}")


# ----------------- VIEW STUDENTS -----------------

def viewStudents():
    print("\nAll Students")

    if not students:
        print("No Students Added Yet")
        return

    for student in students:
        print(
            f"ID: {student['Student_Id']} | "
            f"Name: {student['name']} | "
            f"Age: {student['age']}"
        )


# ----------------- ISSUE BOOK -----------------

def issue_book():
    print("\nIssue Book")

    st_id = int(input("Enter Student ID: "))
    b_id = int(input("Enter Book ID: "))

    student = findStudent(st_id)
    if not student:
        print("Student not found.")
        return

    book = findBook(b_id)
    if not book:
        print("Book not found.")
        return

    if not book["available"]:
        print("Book already issued.")
        return

    issued_record = {
        "bookId": b_id,
        "Student_Id": st_id
    }

    issued_Books.append(issued_record)
    book["available"] = False

    save_books()
    save_issued()

    print(f"Book '{book['title']}' issued to {student['name']}")


# ----------------- VIEW ISSUED BOOKS -----------------

def view_issued_books():
    print("\nIssued Books")

    if not issued_Books:
        print("No Issued Books")
        return

    for record in issued_Books:
        book = findBook(record["bookId"])
        student = findStudent(record["Student_Id"])

        if book and student:
            print(f"Book '{book['title']}' issued to {student['name']}")


# ----------------- MAIN MENU -----------------

def main():
    load_data()

    while True:
        print("\n===== SIMPLE LIBRARY SYSTEM =====")
        print("1. Add Book")
        print("2. View Books")
        print("3. Add Student")
        print("4. View Students")
        print("5. Issue Book")
        print("6. View Issued Books")
        print("0. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            addBook()
        elif choice == "2":
            viewBooks()
        elif choice == "3":
            addStudents()
        elif choice == "4":
            viewStudents()
        elif choice == "5":
            issue_book()
        elif choice == "6":
            view_issued_books()
        elif choice == "0":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")


# ----------------- START PROGRAM -----------------

if __name__ == "__main__":
    main()
