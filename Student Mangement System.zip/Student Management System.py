import json 
print("\t\t\t========= Student Management System ==========\n")

students = []


def loadData():
    global students
    try:
        with open("student.txt",'r') as f:
           students=json.load(f)
    except:
        students=[]


def saveStudent():
    with open("student.txt", "w") as f:
        json.dump(students, f, indent=4)


def generate_student_id():
    if not students:
        return 1
    return max(student["StudentID"] for student in students) + 1

def addstudent():
    while True:
        name = input("Enter Student Name (E to Exit): ")
        if name.lower() == 'e':
            break

        try:
            age = int(input("Enter Student Age: "))
            marks = int(input(f"Enter Marks for {name}: "))
        except ValueError:
            print("Age and Marks must be numbers\n")
            continue

        course = input("Enter Student Course: ")

        student = {
            "StudentID": generate_student_id(),
            "Name": name,
            "Age": age,
            "Course": course,
            "Marks": marks
        }

        students.append(student)
        saveStudent()
        print("Student Added Successfully\n")


def viewStudent():
    if not students:
        print("No Student Available\n")
        return
    for student in students:
        print(f"StudentID:{student['StudentID']} | "
              f"Name: {student['Name']} | "
              f"Age:{student['Age']} | "
              f"Course: {student['Course']} | "
              f"Marks:{student['Marks']}")
    print()

def search_ByStudent_Id(sid):
    for student in students:
        if student['StudentID'] == sid:
            print("Student Found\n")
            print(student)
            return
    print("ID Does Not Exist\n")

def delete_Student_BYID(sid):
    for student in students:
        if student['StudentID'] == sid:
            students.remove(student)
            saveStudent()
            print("Student Deleted Successfully\n")
            return
       
    print("ID Does Not Exist\n")

def update_Student_ByID(sid):
    for student in students:
        if student['StudentID'] == sid:
            student['Name'] = input("Enter New Name: ")
            student['Age'] = int(input("Enter New Age: "))
            student['Course'] = input("Enter New Course: ")
            student['Marks'] = int(input("Enter New Marks: "))
            saveStudent()
            print("Student Updated Successfully\n")
            return
    print("ID Does Not Exist\n")

loadData()
while True:
    print("1. Add Student")
    print("2. View Students")
    print("3. Search Student By ID")
    print("4. Delete Student By ID")
    print("5. Update Student By ID")
    print("6. Exit")

    choice = int(input("Enter Your Choice: "))

    if choice == 1:
        addstudent()
    elif choice == 2:
        viewStudent()
    elif choice == 3:
        sid = int(input("Enter Student ID: "))
        search_ByStudent_Id(sid)
    elif choice == 4:
        sid = int(input("Enter Student ID: "))
        delete_Student_BYID(sid)
    elif choice == 5:
        sid = int(input("Enter Student ID: "))
        update_Student_ByID(sid)
    elif choice == 6:
        print("Exiting Program")
        break
    else:
        print("Invalid Choice\n")
